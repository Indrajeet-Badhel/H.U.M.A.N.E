class FinalMergerAgent:
    def __init__(self):
        pass
    
    def is_conversational_query(self, user_input):
        """Check if this is a personal/conversational query"""
        personal_keywords = ["think", "look", "opinion", "feel", "like me", "about me", "handsome", "smart"]
        return any(keyword in user_input.lower() for keyword in personal_keywords)
    
    def merge_responses(self, agent_responses, user_input="", image_caption=""):
        # Filter out empty or flagged responses
        valid_responses = [resp for resp in agent_responses.values()
                          if resp and "Prompt flagged" not in resp and "error" not in resp.lower()]
        
        if not valid_responses:
            return "Sorry, I couldn't find a useful answer for your request."
        
        # If this is a conversational query and we have a conversational response, prioritize it
        if self.is_conversational_query(user_input) and "conversational" in agent_responses:
            conv_response = agent_responses["conversational"]
            if conv_response and "error" not in conv_response.lower():
                # Add a bit of context if helpful
                context_note = ""
                if image_caption and "food" in image_caption.lower():
                    context_note = f"\n\n(I can see that delicious {image_caption.split('with')[-1].strip() if 'with' in image_caption else 'meal'} by the way! 🍽️)"
                
                return conv_response + context_note
        
        # For non-conversational queries, merge responses as before
        combined_text = "\n\n".join(
            f"{agent.capitalize()}: {resp}"
            for agent, resp in agent_responses.items()
            if resp and "Prompt flagged" not in resp and "error" not in resp.lower()
        )
        
        return f"Based on your request about '{user_input}' and the image showing '{image_caption}':\n\n{combined_text}"