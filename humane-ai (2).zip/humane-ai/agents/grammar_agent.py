import requests

class GrammarAgent:
    def __init__(self):
        self.api_url = "https://api.languagetoolplus.com/v2/check"

    def correct(self, text):
        data = {
            "text": text,
            "language": "en-US"
        }
        try:
            response = requests.post(self.api_url, data=data, timeout=10)
            if response.status_code == 200:
                matches = response.json().get("matches", [])
                corrected = list(text)
                offset = 0
                for match in matches:
                    replacements = match.get("replacements", [])
                    if replacements:
                        replacement = replacements[0]["value"]
                        start = match["offset"] + offset
                        end = start + match["length"]
                        corrected[start:end] = list(replacement)
                        offset += len(replacement) - match["length"]
                return "".join(corrected)
            else:
                return text
        except Exception:
            return text
# agents/grammar_agent.py