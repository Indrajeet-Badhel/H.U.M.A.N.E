import requests
import os

class SummarizationAgent:
    def __init__(self):
        self.api_url = "https://api-inference.huggingface.co/models/facebook/bart-large-cnn"
        self.api_key = os.getenv("HF_API_TOKEN")

    def handle_prompt(self, prompt):
        headers = {"Authorization": f"Bearer {self.api_key}"}
        data = {"inputs": prompt}
        response = requests.post(self.api_url, headers=headers, json=data, timeout=15)
        if response.status_code == 200:
            return response.json()[0].get("summary_text", "").strip()
        else:
            return f"SummarizationAgent error: {response.status_code} {response.text}"
# agents/summarization_agent.py