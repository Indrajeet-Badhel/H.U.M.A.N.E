import requests
import os

class GeneralAgent:
    def __init__(self):
        self.api_url = "https://api.cohere.ai/v1/generate"
        self.api_key = os.getenv("COHERE_API_KEY")

    def handle_prompt(self, prompt):
        headers = {"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"}
        data = {"model": "command", "prompt": prompt, "max_tokens": 150}
        response = requests.post(self.api_url, headers=headers, json=data, timeout=15)
        if response.status_code == 200:
            return response.json().get("generations", [{}])[0].get("text", "").strip()
        else:
            return f"GeneralAgent error: {response.status_code} {response.text}"
# agents/general_agent.py