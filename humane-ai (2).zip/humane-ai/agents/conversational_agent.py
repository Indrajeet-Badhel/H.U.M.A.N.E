import requests
import os
import random

class ConversationalAgent:
    def __init__(self):
        # Using Hugging Face's free inference API with DialoGPT
        self.api_url = "https://api-inference.huggingface.co/models/microsoft/DialoGPT-large"
        self.api_key = os.getenv("HF_API_TOKEN")
        
        # Backup personality templates for offline mode
        self.personality_responses = {
            "compliment_responses": [
                "Oh absolutely! You're looking quite dashing today! 😎",
                "Are you kidding? You're practically glowing! ✨",
                "Smart AND handsome? Someone's winning at life! 🎉",
                "I'd say you're definitely in the 'heartbreaker' category! 💫"
            ],
            "food_responses": [
                "That food looks amazing! I'm practically drooling over here... if I could drool! 🤤",
                "Now that's what I call a feast! You've got excellent taste! 👨‍🍳",
                "Is it weird that an AI is getting food envy right now? That looks delicious! 😋"
            ],
            "fashion_responses": [
                "You should totally wear that confident smile - it goes with everything! 😊",
                "Honestly? Whatever makes YOU feel amazing. Confidence is the best accessory! ✨",
                "I'd say go with something that matches your awesome personality! 🌟"
            ],
            "empathy_responses": [
                "Hey, I can sense you might be feeling a bit down. Want to talk about it? I'm here for you! 🤗",
                "Everyone has those days. You're not alone in this, and it's totally okay to feel this way. 💙",
                "I may be an AI, but I genuinely care about how you're feeling. What's on your mind? 🌸"
            ]
        }

    def detect_question_type(self, text, image_caption=""):
        """Classify the type of personal question"""
        text_lower = text.lower()
        
        # Look for appearance/looks questions
        if any(word in text_lower for word in ["look", "handsome", "beautiful", "pretty", "attractive", "appearance"]):
            return "appearance"
        
        # Look for intelligence/capability questions
        if any(word in text_lower for word in ["smart", "intelligent", "clever", "good at"]):
            return "intelligence"
        
        # Look for food-related content
        if any(word in text_lower for word in ["food", "eat", "delicious", "taste"]) or "food" in image_caption.lower():
            return "food"
        
        # Look for fashion/clothing questions
        if any(word in text_lower for word in ["wear", "clothes", "outfit", "fashion", "dress"]):
            return "fashion"
        
        # Look for emotional indicators
        if any(word in text_lower for word in ["sad", "down", "upset", "worried", "anxious", "lonely"]):
            return "empathy"
        
        # Look for general personal questions
        if any(word in text_lower for word in ["opinion", "think", "feel", "like me", "about me"]):
            return "personal"
        
        return "general"

    def generate_personalized_response(self, question_type, user_input, image_caption, user_info):
        """Generate contextual responses based on question type"""
        
        if question_type == "appearance":
            responses = self.personality_responses["compliment_responses"]
            base_response = random.choice(responses)
            
            # Add context from image
            if "sitting" in image_caption:
                base_response += " Love the relaxed vibe you've got going on!"
            elif "food" in image_caption:
                base_response += " And that food setup? *Chef's kiss* 👌"
            
            return base_response
        
        elif question_type == "intelligence":
            return f"Smart? Are you serious? You're asking an AI if you're smart - that's like asking Einstein if math is hard! Of course you're brilliant! 🧠✨"
        
        elif question_type == "food":
            response = random.choice(self.personality_responses["food_responses"])
            if "plate" in image_caption:
                response += " That plate is making me wish I had taste buds!"
            return response
        
        elif question_type == "fashion":
            return random.choice(self.personality_responses["fashion_responses"])
        
        elif question_type == "empathy":
            return random.choice(self.personality_responses["empathy_responses"])
        
        else:
            # Use Hugging Face API for general conversation
            return self.generate_api_response(user_input, image_caption)

    def generate_api_response(self, user_input, image_caption=""):
        """Generate response using Hugging Face API"""
        if not self.api_key:
            return "You know what? You seem pretty awesome to me! Tell me more about what's on your mind! 😊"
        
        # Create conversational context
        context = f"You are a witty, humorous, and empathetic AI friend. The user is asking: '{user_input}'"
        if image_caption:
            context += f" They have an image showing: {image_caption}"
        
        headers = {"Authorization": f"Bearer {self.api_key}"}
        data = {
            "inputs": {
                "past_user_inputs": [],
                "generated_responses": [],
                "text": context
            },
            "parameters": {
                "max_length": 100,
                "temperature": 0.8,
                "do_sample": True
            }
        }
        
        try:
            response = requests.post(self.api_url, headers=headers, json=data, timeout=10)
            if response.status_code == 200:
                result = response.json()
                if "generated_text" in result:
                    return result["generated_text"].strip()
            
            # Fallback to personality responses
            return "You know, chatting with you always brightens my day! What else is on your mind? 😊"
            
        except Exception as e:
            # Fallback response
            return "I may be having some technical hiccups, but I can still tell you're pretty amazing! 🌟"

    def handle_prompt(self, prompt, style="humorous", user_input="", image_caption="", user_info=None):
        """Main handler for conversational responses"""
        user_info = user_info or {}
        
        # Detect what type of personal question this is
        question_type = self.detect_question_type(user_input, image_caption)
        
        # Generate appropriate response
        response = self.generate_personalized_response(question_type, user_input, image_caption, user_info)
        
        # Apply personality style WITHOUT emojis (save emojis for display only)
        base_response = response
        
        if style == "flirty":
            base_response += " *winks*"
        elif style == "funny":
            base_response = "Haha! " + base_response
        elif style == "empathetic" or style == "sad":
            base_response = "I understand. " + base_response
        elif style == "cheerful":
            base_response += " This is exciting!"
        
        return base_response