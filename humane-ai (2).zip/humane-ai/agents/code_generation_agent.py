import requests
import os

class CodeGenerationAgent:
    def __init__(self):
        self.api_url = "https://api-inference.huggingface.co/models/bigcode/starcoder"
        self.api_key = os.getenv("HF_API_TOKEN")

    def handle_prompt(self, prompt):
        headers = {"Authorization": f"Bearer {self.api_key}"}
        data = {"inputs": prompt, "parameters": {"max_new_tokens": 128}}
        response = requests.post(self.api_url, headers=headers, json=data, timeout=30)
        if response.status_code == 200:
            return response.json()[0].get("generated_text", "").strip()
        else:
            return f"CodeGenerationAgent error: {response.status_code} {response.text}"
# agents/code_generation_agent.py