# voice_input/tone_analyzer.py

from transformers import AutoTokenizer, AutoModelForSequenceClassification
import torch
import numpy as np

MODEL_NAME = "cardiffnlp/twitter-roberta-base-sentiment-latest"
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForSequenceClassification.from_pretrained(MODEL_NAME)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = model.to(device)

def analyze_sentiment(text):
    if not text or not text.strip():
        return "No text provided.", {}
    inputs = tokenizer(text, return_tensors="pt", truncation=True, padding=True).to(device)
    with torch.no_grad():
        outputs = model(**inputs)
        scores = outputs.logits[0].numpy()
        scores = np.exp(scores) / np.exp(scores).sum()
        labels = ["Negative", "Neutral", "Positive"]
        sentiment = labels[scores.argmax()]
        detailed = dict(zip(labels, scores.round(3)))
        print(f"Sentiment: {sentiment} | Scores: {detailed}")
        return {"sentiment": sentiment, "scores": detailed}
