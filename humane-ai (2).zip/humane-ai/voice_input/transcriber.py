import whisper
import torch
import gc

def transcribe_audio(audio_path="data/saved_audio/input.wav", model_size="base"):
    print("🧠 Loading Whisper model:", model_size)
    
    # Clear GPU memory before loading Whisper
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
        gc.collect()
    
    # Load Whisper on CPU to save GPU memory
    device = "cpu"  # Force CPU usage for Whisper
    print(f"Loading Whisper on {device} to conserve GPU memory...")
    
    model = whisper.load_model(model_size, device=device)
    
    print("🔍 Transcribing audio...")
    result = model.transcribe(audio_path)
    text = result["text"]
    print("📝 Transcription:", text)
    
    # Clean up model from memory immediately
    del model
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
    
    return text
