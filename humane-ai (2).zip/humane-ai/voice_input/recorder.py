import pyaudio
import wave
import os
import keyboard  # You need to install this package: pip install keyboard

def record_audio(output_path="data/saved_audio/input.wav"):
    FORMAT = pyaudio.paInt16
    CHANNELS = 1
    RATE = 16000
    CHUNK = 1024

    p = pyaudio.PyAudio()
    stream = p.open(format=FORMAT, channels=CHANNELS, rate=RATE,
                    input=True, frames_per_buffer=CHUNK)

    print("Hold SPACEBAR to record. Release to stop.")

    frames = []
    try:
        while True:
            if keyboard.is_pressed('space'):
                print("Recording...")
                while keyboard.is_pressed('space'):
                    data = stream.read(CHUNK)
                    frames.append(data)
                break  # Stop recording when spacebar released
    except KeyboardInterrupt:
        print("Recording interrupted.")
    finally:
        print("Saving audio...")
        stream.stop_stream()
        stream.close()
        p.terminate()

    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    wf = wave.open(output_path, 'wb')
    wf.setnchannels(CHANNELS)
    wf.setsampwidth(p.get_sample_size(FORMAT))
    wf.setframerate(RATE)
    wf.writeframes(b''.join(frames))
    wf.close()

    print(f"Audio saved to {output_path}")
    return output_path
