import json
import os
import tempfile

class MemoryManager:
    def __init__(self, db_path='memory/memory_db.json'):
        self.db_path = db_path
        if not os.path.exists(db_path):
            os.makedirs(os.path.dirname(db_path), exist_ok=True)
            with open(db_path, 'w', encoding='utf-8') as f:
                json.dump({"conversations": [], "personal_info": {}}, f, indent=2)
        self.load_memory()

    def load_memory(self):
        with open(self.db_path, 'r', encoding='utf-8') as f:
            self.memory = json.load(f)

    def save_memory(self):
        dir_name = os.path.dirname(self.db_path)
        with tempfile.NamedTemporaryFile('w', dir=dir_name, delete=False, encoding='utf-8') as tf:
            json.dump(self.memory, tf, indent=2)
            tempname = tf.name
        os.replace(tempname, self.db_path)

    def add_conversation(self, user_input, bot_response):
        if self.memory["conversations"]:
            last = self.memory["conversations"][-1]
            if last["user"] == user_input and last["bot"] == bot_response:
                return
        self.memory["conversations"].append({
            "user": user_input,
            "bot": bot_response
        })
        self.save_memory()

    def update_personal_info(self, info_dict):
        if not isinstance(info_dict, dict):
            raise ValueError("Personal info must be a dictionary")
        self.memory["personal_info"].update(info_dict)
        self.save_memory()

    def get_personal_info(self):
        return self.memory.get("personal_info", {})

    def get_conversations(self):
        return self.memory.get("conversations", [])

    def query_personal_info(self, keys):
        personal_info = self.get_personal_info()
        result = {}
        for key in keys:
            found_key = next((k for k in personal_info if k.lower() == key.lower()), None)
            if found_key:
                result[key] = personal_info[found_key]
            else:
                result[key] = None
        return result
