import os
import requests
import re

class PersonalInfoExtractor:
    def __init__(self, memory_manager):
        self.memory_manager = memory_manager
        self.dandelion_token = os.getenv("DANDELION_API_TOKEN")
        self.hf_api_token = os.getenv("HF_API_TOKEN")
        self.dandelion_url = "https://api.dandelion.eu/datatxt/nex/v1/"
        self.hf_api_url = "https://api-inference.huggingface.co/models/dbmdz/bert-large-cased-finetuned-conll03-english"
        if not self.dandelion_token:
            raise ValueError("Set DANDELION_API_TOKEN in your .env file")

    def query_dandelion(self, text):
        params = {
            "text": text,
            "lang": "en",
            "token": self.dandelion_token,
            "include": "types"
        }
        try:
            response = requests.get(self.dandelion_url, params=params, timeout=10)
            if response.status_code == 200:
                return response.json()
            else:
                print(f"Dandelion API error: {response.status_code} {response.text}")
                return {}
        except Exception as e:
            print(f"Error calling Dandelion API: {e}")
            return {}

    def query_hf_api(self, text):
        if not self.hf_api_token:
            print("No Hugging Face API token set.")
            return []
        headers = {"Authorization": f"Bearer {self.hf_api_token}"}
        payload = {"inputs": text}
        try:
            response = requests.post(self.hf_api_url, headers=headers, json=payload, timeout=10)
            if response.status_code == 200:
                return response.json()
            else:
                print(f"Hugging Face API error: {response.status_code} {response.text}")
                return []
        except Exception as e:
            print(f"Error calling Hugging Face NER API: {e}")
            return []

    def extract_custom_info(self, text):
        info = {}

        # Class/grade/year/standard
        class_matches = re.findall(r'\b(class|grade|year|standard)\s*\d+\w*', text, re.IGNORECASE)
        if class_matches:
            info["class"] = class_matches

        # Likes/preferences
        likes = re.findall(r'\bI like ([^.,;]+)', text, re.IGNORECASE)
        if likes:
            info["likes"] = [like.strip() for like in likes]

        dislikes = re.findall(r"\bI (?:don't like|dislike|hate) ([^.,;]+)", text, re.IGNORECASE)
        if dislikes:
            info["dislikes"] = [dislike.strip() for dislike in dislikes]

        # Hobbies/interests
        hobbies = re.findall(r'\bmy hobby is ([^.,;]+)', text, re.IGNORECASE)
        if hobbies:
            info["hobbies"] = [hobby.strip() for hobby in hobbies]

        # Favorite things
        favorites = re.findall(r'\bfavorite (\w+) is ([^.,;]+)', text, re.IGNORECASE)
        for category, value in favorites:
            key = f"favorite_{category.lower()}"
            info.setdefault(key, []).append(value.strip())

        # "I am" statements
        i_am = re.findall(r'\bI am ([^.,;]+)', text, re.IGNORECASE)
        if i_am:
            info["i_am"] = [x.strip() for x in i_am]

        # "I have" statements
        i_have = re.findall(r'\bI have ([^.,;]+)', text, re.IGNORECASE)
        if i_have:
            info["i_have"] = [x.strip() for x in i_have]

        # "I want" statements
        i_want = re.findall(r'\bI want ([^.,;]+)', text, re.IGNORECASE)
        if i_want:
            info["i_want"] = [x.strip() for x in i_want]

        return info

    def extract(self, text):
        info = {}

        # --- Dandelion NER Extraction ---
        dandelion_result = self.query_dandelion(text)
        annotations = dandelion_result.get("annotations", [])
        if annotations:
            for ann in annotations:
                types = ann.get("types", [])
                entity_type = types[0].split(':')[-1].lower() if types else "entity"
                entity_word = ann.get("spot", "").strip()
                if entity_word:
                    info.setdefault(entity_type, set()).add(entity_word)
        else:
            # --- Fallback to Hugging Face NER API ---
            hf_entities = self.query_hf_api(text)
            for ent in hf_entities:
                entity_type = ent.get("entity_group", "unknown").lower()
                entity_word = ent.get("word", "").strip()
                if entity_word:
                    info.setdefault(entity_type, set()).add(entity_word)

        # --- Custom regex extraction ---
        custom_info = self.extract_custom_info(text)
        for key, val in custom_info.items():
            info.setdefault(key, set()).update(val)

        # Convert sets to lists for JSON compatibility
        for key in info:
            info[key] = list(info[key])

        # Update long-term memory
        if info:
            self.memory_manager.update_personal_info(info)

        return info
