# safety_guard/filter.py

from profanityfilter import ProfanityFilter
import requests
import os
from dotenv import load_dotenv
load_dotenv()

# Initialize the profanity filter
pf = ProfanityFilter()

# --- Text Profanity Filtering ---

def is_text_clean(text):
    """
    Returns True if text is clean (no profanity), False otherwise.
    """
    return pf.is_clean(text)

def censor_text(text):
    """
    Returns the censored version of the text.
    """
    return pf.censor(text)

# --- Image NSFW Filtering (DeepAI API) ---

def is_image_safe(image_path, api_key=None, threshold=0.8):
    """
    Returns True if image is safe (not NSFW), False if NSFW content is detected.
    Uses DeepAI NSFW Detector API. Set your DeepAI API key as an environment variable or pass as argument.
    """
    if api_key is None:
        api_key = os.environ.get("DEEPAI_API_KEY", None)
    if not api_key:
        raise ValueError("DeepAI API key required. Set DEEPAI_API_KEY env variable or pass api_key argument.")

    url = 'https://api.deepai.org/api/nsfw-detector'
    with open(image_path, 'rb') as img_file:
        response = requests.post(
            url,
            files={'image': img_file},
            headers={'api-key': api_key}
        )
    response_json = response.json()
    # DeepAI returns a list of detections with 'nsfw_score' between 0 (safe) and 1 (very unsafe)
    nsfw_score = response_json.get('output', {}).get('nsfw_score', 0)
    return nsfw_score < threshold
