# ✅ CREATE this new file:
import time
import torch
try:
    import GPUtil
    GPU_UTIL_AVAILABLE = True
except ImportError:
    GPU_UTIL_AVAILABLE = False
    print("GPUtil not installed. Install with: pip install gputil")

def monitor_gpu_performance():
    """Monitor GPU utilization and performance"""
    if not torch.cuda.is_available():
        print("CUDA not available")
        return
    
    print(f"PyTorch CUDA Version: {torch.version.cuda}")
    print(f"GPU Device: {torch.cuda.get_device_name()}")
    print(f"Memory Allocated: {torch.cuda.memory_allocated() / 1024**2:.2f} MB")
    print(f"Memory Reserved: {torch.cuda.memory_reserved() / 1024**2:.2f} MB")
    
    if GPU_UTIL_AVAILABLE:
        gpus = GPUtil.getGPUs()
        for gpu in gpus:
            print(f"GPU {gpu.id}: {gpu.name}")
            print(f"  Memory Usage: {gpu.memoryUtil*100:.1f}%")
            print(f"  GPU Usage: {gpu.load*100:.1f}%")
            print(f"  Temperature: {gpu.temperature}°C")

def benchmark_function(func, *args, **kwargs):
    """Benchmark function execution time"""
    if torch.cuda.is_available():
        torch.cuda.synchronize()
    
    start_time = time.time()
    result = func(*args, **kwargs)
    
    if torch.cuda.is_available():
        torch.cuda.synchronize()
    
    end_time = time.time()
    print(f"Function {func.__name__} took {end_time - start_time:.4f} seconds")
    return result
