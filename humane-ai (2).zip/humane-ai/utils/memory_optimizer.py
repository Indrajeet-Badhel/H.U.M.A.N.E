import torch
import gc
from contextlib import contextmanager

class GPUMemoryManager:
    def __init__(self):
        self.loaded_models = {}
    
    def clear_gpu_memory(self):
        """Aggressively clear GPU memory"""
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
            torch.cuda.synchronize()
        gc.collect()
    
    @contextmanager
    def temporary_model(self, model_name, model_loader_func):
        """Load model temporarily, then unload"""
        try:
            self.clear_gpu_memory()
            print(f"Loading {model_name} temporarily...")
            model = model_loader_func()
            yield model
        finally:
            del model
            self.clear_gpu_memory()
            print(f"Unloaded {model_name}")
    
    def get_memory_stats(self):
        """Get current GPU memory usage"""
        if torch.cuda.is_available():
            allocated = torch.cuda.memory_allocated() / 1024**2
            reserved = torch.cuda.memory_reserved() / 1024**2
            return f"GPU Memory - Allocated: {allocated:.1f}MB, Reserved: {reserved:.1f}MB"
        return "CUDA not available"

# Global memory manager
memory_manager = GPUMemoryManager()
