def check_prompt_image_alignment(prompt, image_caption):
    prompt_keywords = set(prompt.lower().split())
    caption_keywords = set(image_caption.lower().split())
    return bool(prompt_keywords & caption_keywords)
