# prompt_converter/build_prompt.py
def build_prompt(agent_type, personal_info, user_input):
    templates = {
        "webscraping": "Webscraping prompt. User info: {info}. Task: {input}",
        "personalised": "Personalised agent prompt. User info: {info}. Input: {input}",
        "summarization": "Summarize for user ({info}): {input}",
        "translation": "Translate for user ({info}): {input}",
        "research": "Research for user ({info}): {input}",
        "code_generation": "Generate code. User info: {info}. Task: {input}"
    }
    # Normalize all values to string for safe joining
    def normalize_value(val):
        if isinstance(val, list):
            return ', '.join(str(v) for v in val if v)
        return str(val)
    info_str = ', '.join(f"{k}: {normalize_value(v)}" for k, v in personal_info.items() if v)
    prompt = templates.get(agent_type, "Prompt: {input}").format(info=info_str, input=user_input)
    return prompt
