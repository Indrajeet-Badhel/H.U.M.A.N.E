# prompt_converter/guardian_check.py

from safety_guard.filter import is_text_clean, censor_text, is_image_safe
from typing import Tuple, Optional

def is_content_appropriate(prompt: str, image_path: Optional[str] = None) -> Tuple[bool, str, Optional[bool]]:
    """
    Checks if the input text and optional image are appropriate.

    Returns a tuple:
    - text_ok (bool): True if prompt is clean, False if it contains profanity
    - cleaned_prompt (str): original or censored prompt
    - image_ok (bool or None): True if image is safe, False if NSFW, None if no image provided
    """
    # Text filtering
    if is_text_clean(prompt):
        text_ok = True
        cleaned_prompt = prompt
    else:
        text_ok = False
        cleaned_prompt = censor_text(prompt)

    # Image filtering (optional)
    image_ok = None
    if image_path:
        try:
            image_ok = is_image_safe(image_path)
        except Exception as e:
            print(f"[Warning] Image check failed: {e}")
            image_ok = False  # Be safe by default

    return text_ok, cleaned_prompt, image_ok
