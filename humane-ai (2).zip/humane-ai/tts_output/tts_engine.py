# tts_engine.py
import os
import torch
import re
from TTS.api import TTS
import torch.serialization
from pydub import AudioSegment
from pydub.playback import play

# Initialize style prompts
STYLE_PROMPTS = {
    "humorous": "(with a playful, witty tone) ",
    "funny": "(with a funny, light-hearted tone) ",
    "flirty": "(with a flirty, charming tone) ",
    "angry": "(angrily) ",
    "sad": "(in a soft, sad tone) ",
    "empathetic": "(with a caring, understanding tone) ",
    "happy": "(with a happy, upbeat tone) ",
    "cheerful": "(with a cheerful, bright voice) ",
    "motivational": "(in a passionate, motivational voice) ",
    "default": ""
}

# Initialize TTS
print("Initializing TTS engine...")
device = "cuda" if torch.cuda.is_available() else "cpu"
MODEL_NAME = "tts_models/en/ljspeech/tacotron2-DDC"
tts = TTS(model_name=MODEL_NAME)
tts.to(device)

if torch.cuda.is_available():
    torch.cuda.empty_cache()

print(f"TTS engine ready on {device}.")

def clean_text_for_tts(text):
    """Clean text by removing emojis and ensuring minimum length"""
    if not text or not isinstance(text, str):
        return "Hello"
    
    # Remove all emojis and special Unicode characters
    emoji_pattern = re.compile("["
                             u"\U0001F600-\U0001F64F"  # emoticons
                             u"\U0001F300-\U0001F5FF"  # symbols & pictographs
                             u"\U0001F680-\U0001F6FF"  # transport & map symbols
                             u"\U0001F1E0-\U0001F1FF"  # flags (iOS)
                             u"\U00002702-\U000027B0"
                             u"\U000024C2-\U0001F251"
                             u"\U0001f926-\U0001f937"
                             u"\U00010000-\U0010ffff"
                             u"\u2640-\u2642"
                             u"\u2600-\u2B55"
                             u"\u200d"
                             u"\u23cf"
                             u"\u23e9"
                             u"\u231a"
                             u"\ufe0f"
                             u"\u3030"
                             "]+", flags=re.UNICODE)
    
    cleaned_text = emoji_pattern.sub('', text).strip()
    
    # Remove extra whitespace
    cleaned_text = re.sub(r'\s+', ' ', cleaned_text)
    
    # Ensure minimum length for TTS processing
    if len(cleaned_text) < 10:
        if cleaned_text:
            cleaned_text = f"Here's what I want to say: {cleaned_text}"
        else:
            cleaned_text = "Hello there!"
    
    return cleaned_text

def speak(text, style="default", output_path="tts_output/output.wav"):
    """
    Generate and play TTS audio with emoji filtering.
    """
    # Clean the text first
    clean_text = clean_text_for_tts(text)
    
    expressive_text = clean_text
    if "xtts" in tts.model_name.lower():
        style_prefix = STYLE_PROMPTS.get(style, "")
        expressive_text = f"{style_prefix}{clean_text}"
    
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    
    try:
        # Generate speech with cleaned text
        tts.tts_to_file(
            text=expressive_text,
            file_path=output_path,
            split_sentences=True
        )
        
        # Play WAV reliably using pydub
        audio = AudioSegment.from_wav(output_path)
        play(audio)
        
        return output_path
        
    except Exception as e:
        print(f"TTS failed with cleaned text: {e}")
        # Fallback to even simpler text
        try:
            fallback_text = "I have something to say."
            tts.tts_to_file(
                text=fallback_text,
                file_path=output_path,
                split_sentences=False
            )
            audio = AudioSegment.from_wav(output_path)
            play(audio)
            return output_path
        except Exception as e2:
            print(f"TTS completely failed: {e2}")
            return None

def clear_gpu_memory():
    """Clear GPU memory to prevent memory leaks"""
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
        torch.cuda.ipc_collect()
        print("GPU memory cleared.")
