# image_capture/image_ai_checker.py

import cv2

def is_image_clear(image_path, threshold=65):
    """
    Returns True if image is clear (not blurry), False otherwise.
    threshold: 60–70 is recommended for moderate blur tolerance.
    """
    img = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    if img is None:
        raise ValueError(f"Cannot load image: {image_path}")
    variance = cv2.Laplacian(img, cv2.CV_64F).var()
    print(f"Image blur score: {variance:.2f} (threshold: {threshold})")
    return variance > threshold
