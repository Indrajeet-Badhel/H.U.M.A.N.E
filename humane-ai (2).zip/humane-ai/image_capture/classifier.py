import torch
from transformers import BlipProcessor, BlipForConditionalGeneration
from PIL import Image
import cv2
import requests
import os

class ImageClassifier:
    def __init__(self, model_name="Salesforce/blip-image-captioning-base"):
        print("Loading BLIP model...")
        self.processor = BlipProcessor.from_pretrained(model_name)
        self.model = BlipForConditionalGeneration.from_pretrained(model_name)
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.model.to(self.device)
        print(f"Model loaded on {self.device}")
        if torch.cuda.is_available():
            self.warm_up_gpu()
    def warm_up_gpu(self):
        """Pre-warm GPU with dummy data for consistent performance"""
        try:
            # Create dummy image tensor
            dummy_image = torch.randn(1, 3, 224, 224)
            if torch.cuda.is_available() and hasattr(self, 'model'):
                dummy_image = dummy_image.cuda()
                with torch.no_grad():
                    # Run a dummy forward pass
                    _ = self.model(dummy_image)
                torch.cuda.synchronize()
        except Exception as e:
            print(f"GPU warmup failed: {e}")
    def load_image(self, image_path):
        """Load image from file path, URL, or OpenCV array."""
        if isinstance(image_path, str):
            if image_path.startswith('http'):
                image = Image.open(requests.get(image_path, stream=True).raw)
            else:
                image = Image.open(image_path)
        else:
            image = Image.fromarray(cv2.cvtColor(image_path, cv2.COLOR_BGR2RGB))
        return image.convert('RGB')

    def generate_caption(self, image, max_length=50):
        """Generate a brief description (caption) for the image."""
        if not isinstance(image, Image.Image):
            image = self.load_image(image)
        inputs = self.processor(image, return_tensors="pt").to(self.device)
        with torch.no_grad():
            out = self.model.generate(**inputs, max_length=max_length, num_beams=5)
        caption = self.processor.decode(out[0], skip_special_tokens=True)
        return caption

if __name__ == "__main__":
    classifier = ImageClassifier()
    # Example usage:
    # Provide the path to your image file below
    image_path = "your_image.jpg"
    caption = classifier.generate_caption(image_path)
    print("Description:", caption)
