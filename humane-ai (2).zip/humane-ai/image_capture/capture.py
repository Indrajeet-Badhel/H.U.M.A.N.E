# image_capture/capture.py

import cv2
import os
from datetime import datetime

class ImageCapture:
    def __init__(self, save_dir="captured_images"):
        self.save_dir = save_dir
        os.makedirs(save_dir, exist_ok=True)

    def capture_from_camera(self, camera_index=0):
        cap = cv2.VideoCapture(camera_index)
        if not cap.isOpened():
            raise Exception("Could not open camera")
        print("Auto-capturing image. Please look at the camera...")
        ret, frame = cap.read()
        if not ret:
            cap.release()
            raise Exception("Failed to capture image from camera.")
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"capture_{timestamp}.jpg"
        filepath = os.path.join(self.save_dir, filename)
        cv2.imwrite(filepath, frame)
        print(f"Image saved: {filepath}")
        cap.release()
        cv2.destroyAllWindows()
        return filepath
