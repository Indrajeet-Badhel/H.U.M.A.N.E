import cv2
import numpy as np
from PIL import Image, ImageEnhance
import os

class ImageEnhancer:
    def __init__(self):
        pass
    
    def enhance_contrast(self, image, factor=1.5):
        """Enhance image contrast"""
        if isinstance(image, str):
            image = cv2.imread(image)
        
        # Convert to PIL for easier enhancement
        pil_image = Image.fromarray(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
        enhancer = ImageEnhance.Contrast(pil_image)
        enhanced = enhancer.enhance(factor)
        
        # Convert back to OpenCV format
        return cv2.cvtColor(np.array(enhanced), cv2.COLOR_RGB2BGR)
    
    def enhance_sharpness(self, image, factor=2.0):
        """Enhance image sharpness"""
        if isinstance(image, str):
            image = cv2.imread(image)
        
        pil_image = Image.fromarray(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
        enhancer = ImageEnhance.Sharpness(pil_image)
        enhanced = enhancer.enhance(factor)
        
        return cv2.cvtColor(np.array(enhanced), cv2.COLOR_RGB2BGR)
    
    def enhance_brightness(self, image, factor=1.2):
        """Enhance image brightness"""
        if isinstance(image, str):
            image = cv2.imread(image)
        
        pil_image = Image.fromarray(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
        enhancer = ImageEnhance.Brightness(pil_image)
        enhanced = enhancer.enhance(factor)
        
        return cv2.cvtColor(np.array(enhanced), cv2.COLOR_RGB2BGR)
    
    def reduce_noise(self, image):
        """Reduce image noise using bilateral filter"""
        if isinstance(image, str):
            image = cv2.imread(image)
        
        return cv2.bilateralFilter(image, 9, 75, 75)
    
    def auto_enhance(self, image, save_path=None):
        """Apply automatic enhancement pipeline"""
        if isinstance(image, str):
            original_path = image
            image = cv2.imread(image)
        else:
            original_path = None
        
        # Enhancement pipeline
        enhanced = self.reduce_noise(image)
        enhanced = self.enhance_contrast(enhanced, 1.3)
        enhanced = self.enhance_sharpness(enhanced, 1.5)
        enhanced = self.enhance_brightness(enhanced, 1.1)
        
        if save_path:
            cv2.imwrite(save_path, enhanced)
            print(f"Enhanced image saved to: {save_path}")
        
        return enhanced
    
    def compare_before_after(self, original_image, enhanced_image):
        """Display before and after comparison"""
        if isinstance(original_image, str):
            original_image = cv2.imread(original_image)
        if isinstance(enhanced_image, str):
            enhanced_image = cv2.imread(enhanced_image)
        
        # Resize images to same height for comparison
        height = min(original_image.shape[0], enhanced_image.shape[0])
        original_resized = cv2.resize(original_image, 
                                    (int(original_image.shape[1] * height / original_image.shape[0]), height))
        enhanced_resized = cv2.resize(enhanced_image, 
                                    (int(enhanced_image.shape[1] * height / enhanced_image.shape[0]), height))
        
        # Concatenate images side by side
        comparison = np.hstack((original_resized, enhanced_resized))
        
        cv2.imshow('Before (Left) vs After (Right)', comparison)
        cv2.waitKey(0)
        cv2.destroyAllWindows()

if __name__ == "__main__":
    enhancer = ImageEnhancer()
    # Example usage
    # enhanced = enhancer.auto_enhance("input_image.jpg", "enhanced_output.jpg")
