import os
import sys
import json
import numpy as np
import torch
from transformers import AutoTokenizer, AutoModelForSequenceClassification
from agents.final_merger_agent import FinalMergerAgent
from image_capture.capture import ImageCapture
from image_capture.enhancer import ImageEnhancer
from image_capture.classifier import ImageClassifier
from image_capture.image_ai_checker import is_image_clear
from utils.convert_np import convert_np
from utils.memory_optimizer import memory_manager
from utils.gpu_monitor import monitor_gpu_performance, benchmark_function
from safety_guard.filter import is_text_clean, censor_text, is_image_safe
from memory.memory_manager import MemoryManager
from memory.personal_info_extractor import PersonalInfoExtractor
from voice_input.recorder import record_audio
from voice_input.transcriber import transcribe_audio
from agents.grammar_agent import GrammarAgent
from agent_manager import AgentManager
from tts_output.tts_engine import speak
import threading
import time
import torch
import torch.cuda as cuda
from torch.cuda.amp import autocast

MODEL_NAME = "cardiffnlp/twitter-roberta-base-sentiment-latest"
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForSequenceClassification.from_pretrained(
    MODEL_NAME,
    torch_dtype=torch.float16,  # Half precision for speed
    device_map="cuda" if torch.cuda.is_available() else "cpu"
)
model.eval()  # Set to evaluation mode

# Enable CUDA optimizations
if torch.cuda.is_available():
    torch.backends.cudnn.benchmark = True
    torch.cuda.empty_cache()

SENTIMENT_TO_STYLE = {
    "Positive": "cheerful",
    "Negative": "empathetic",  # Changed from "sad" to "empathetic"
    "Neutral": "humorous"      # Changed from "default" to "humorous"
}

speak_lock = threading.Lock()

def analyze_sentiment(text):
    """Optimized sentiment analysis with GPU acceleration"""
    if not text or not text.strip():
        return "Neutral", {"Negative": 0.33, "Neutral": 0.33, "Positive": 0.33}
    
    # GPU-optimized tokenization
    inputs = tokenizer(
        text, 
        return_tensors="pt", 
        truncation=True, 
        padding=True,
        max_length=128  # Limit length for speed
    )
    
    # Move to GPU if available
    if torch.cuda.is_available():
        inputs = {k: v.to("cuda") for k, v in inputs.items()}

    with torch.no_grad(), torch.amp.autocast('cuda', enabled=torch.cuda.is_available()):  # Mixed precision
        outputs = model(**inputs)
        scores = torch.nn.functional.softmax(outputs.logits[0], dim=0)
        
    scores_np = scores.cpu().numpy() if torch.cuda.is_available() else scores.numpy()
    labels = ["Negative", "Neutral", "Positive"]
    sentiment = labels[scores_np.argmax()]
    detailed = dict(zip(labels, [float(s) for s in scores_np.round(3)]))
    
    return sentiment, detailed

def detect_emotional_state(text, sentiment_scores):
    """Enhanced emotional state detection for better personality matching"""
    sadness_indicators = ["sad", "down", "depressed", "lonely", "upset", "disappointed", "worried", "anxious"]
    excitement_indicators = ["excited", "happy", "thrilled", "amazing", "awesome", "great", "fantastic", "wonderful"]
    personal_indicators = ["do you think", "how do i look", "am i", "what should i wear", "your opinion", "about me"]
    
    text_lower = text.lower()
    
    # Check for personal questions first (highest priority for conversational responses)
    if any(indicator in text_lower for indicator in personal_indicators):
        return "conversational"
    
    # Check for emotional indicators
    if any(indicator in text_lower for indicator in sadness_indicators):
        return "empathetic"
    elif any(indicator in text_lower for indicator in excitement_indicators):
        return "cheerful"
    elif sentiment_scores.get("Positive", 0) > 0.6:
        return "cheerful"
    elif sentiment_scores.get("Negative", 0) > 0.6:
        return "empathetic"
    else:
        return "humorous"

def user_wants_to_exit(text):
    exit_phrases = ["stop listening", "goodbye", "exit", "quit"]
    return any(phrase in text.lower() for phrase in exit_phrases)

def user_requested_image(user_text):
    triggers = ["look this", "see this", "capture this", "look at this", "new image", "take picture"]
    return any(trigger in user_text.lower() for trigger in triggers)

class ImageProcessingPipeline:
    def __init__(self):
        self.capturer = ImageCapture()
        self.enhancer = ImageEnhancer()
        self.classifier = ImageClassifier()
        
    def process_image(self, enhance=True, classify=True):
        clear = False
        attempts = 0
        max_attempts = 3
        
        while not clear and attempts < max_attempts:
            image_path = self.capturer.capture_from_camera()
            clear = is_image_clear(image_path, threshold=30)  # Lower threshold for easier capture
            attempts += 1
            
            if not clear and attempts < max_attempts:
                print(f"Image not clear enough, retrying... (Attempt {attempts + 1}/{max_attempts})")
        
        result = {"original": image_path}
        
        if enhance:
            enhanced_path = image_path.replace(".jpg", "_enhanced.jpg")
            self.enhancer.auto_enhance(image_path, enhanced_path)
            result["enhanced"] = enhanced_path
            
        if classify:
            analysis_image = result.get("enhanced", image_path)
            caption = self.classifier.generate_caption(analysis_image)
            result["classification"] = {"caption": caption}
            
        return result

def speak_with_delay(text, style="default", interval=2):
    """Wrapper function to add delay after TTS speech"""
    with speak_lock:
        # Import the TTS speak function with a different name
        from tts_output.tts_engine import speak as tts_speak
        tts_speak(text, style=style)
        time.sleep(interval)

def main():
    # Initialize components
    memory_manager_instance = MemoryManager()
    personal_info_extractor = PersonalInfoExtractor(memory_manager_instance)
    agent_manager = AgentManager()
    grammar_agent = GrammarAgent()
    pipeline = ImageProcessingPipeline()
    final_merger = FinalMergerAgent()
    
    # State variables
    img_caption = None
    image_path = None
    user_voice_corrected = ""
    awaiting_image_instruction = False

    # GPU memory management
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
        torch.cuda.set_per_process_memory_fraction(0.8)
        print(f"GPU Memory Allocated: {torch.cuda.memory_allocated() / 1024**2:.2f} MB")
        print(f"GPU Memory Cached: {torch.cuda.memory_reserved() / 1024**2:.2f} MB")

    # Welcome message with personality
    speak_with_delay("Hey there! 👋 Your Humane AI Assistant is ready to chat! Say 'look this' to capture a new image or 'stop listening' to exit.", style="cheerful")
    monitor_gpu_performance()
    
    while True:
        try:
            # Image capture and processing
            if img_caption is None or awaiting_image_instruction:
                speak_with_delay("Capturing image now. Strike a pose! 📸", style="cheerful")
                img_result = pipeline.process_image()
                image_path = img_result["original"]
                img_caption = img_result["classification"]["caption"]
                speak_with_delay(f"Image description: {img_caption}", style="cheerful")
                
                # Safety check with better error handling
                try:
                    if not is_image_safe(image_path):
                        speak_with_delay("Oops! That image seems a bit inappropriate. Let's try again! 😅", style="humorous")
                        continue
                except Exception as e:
                    print(f"Image safety check failed: {e}")
                    speak_with_delay("Having some technical hiccups with the safety check, but we're good to go! 🤖", style="humorous")
                
                speak_with_delay("What would you like me to do with this image? I'm all ears! 👂", style="cheerful")
                awaiting_image_instruction = False

            # Voice input
            speak_with_delay("Listening for your command...", style="default")
            audio_path = record_audio()
            
            # Memory management for transcription
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
                print(f"GPU Memory Before Transcription: {torch.cuda.memory_allocated() / 1024**2:.2f} MB")

            user_voice_raw = transcribe_audio(audio_path).strip()

            # Clear memory after transcription
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
     
            if not user_voice_raw:
                speak_with_delay("Hmm, I couldn't hear anything. Could you speak a bit louder? I promise I'm listening! 👂", style="humorous")
                continue

            # Exit condition
            if user_wants_to_exit(user_voice_raw):
                speak_with_delay("Aww, goodbye! Thanks for the fun chat! Come back anytime! 👋✨", style="cheerful")
                break

            # Content safety check
            if not is_text_clean(user_voice_raw):
                speak_with_delay("Whoa there! Let's keep things friendly and fun! 😊", style="humorous")
                continue

            # Grammar correction
            user_voice_corrected = grammar_agent.correct(user_voice_raw)

            # Image request handling
            if user_requested_image(user_voice_corrected):
                awaiting_image_instruction = True
                continue

            # Extract personal information and analyze sentiment
            extracted_info = personal_info_extractor.extract(user_voice_corrected)
            sentiment_label, sentiment_scores = analyze_sentiment(user_voice_corrected)
            
            # Detect emotional state for better personality matching
            emotional_state = detect_emotional_state(user_voice_corrected, sentiment_scores)

            # Generate responses using the agent manager
            raw_agent_outputs = agent_manager.generate_and_route_prompts(
                img_caption, user_voice_corrected, emotional_state, sentiment_scores, extracted_info
            )

            # Merge responses with context
            final_output = final_merger.merge_responses(
                raw_agent_outputs, 
                user_input=user_voice_corrected, 
                image_caption=img_caption
            )
            
            # Determine voice style based on emotional state
            voice_style = SENTIMENT_TO_STYLE.get(sentiment_label, "humorous")
            speak_with_delay(final_output, style=voice_style)

            # Save results for debugging
            results = {
                "image_caption": img_caption,
                "sentiment": sentiment_label,
                "sentiment_scores": sentiment_scores,
                "emotional_state": emotional_state,
                "extracted_personal_info": extracted_info,
                "agent_output": final_output,
                "timestamp": time.strftime("%Y-%m-%d %H:%M:%S")
            }
            
            with open("pipeline_results.json", "w") as f:
                json.dump(convert_np(results), f, indent=2)

            # Wait for next instruction
            speak_with_delay("What else can I help you with? Say 'look this' for a new image or 'stop listening' to exit! 🎉", style="cheerful")

        except KeyboardInterrupt:
            speak_with_delay("Goodbye! Thanks for chatting with me! 👋", style="cheerful")
            break
        except Exception as e:
            print(f"Error in main loop: {e}")
            speak_with_delay("Oops! I had a little glitch, but I'm back and ready to help! 🤖✨", style="humorous")
            continue

if __name__ == "__main__":
    main()
