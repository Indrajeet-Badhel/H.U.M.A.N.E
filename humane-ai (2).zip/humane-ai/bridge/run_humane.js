// bridge/run_humane.js
const express = require('express');
const { PythonShell } = require('python-shell');
const app = express();
const port = 5050;

app.get('/run', (req, res) => {
  PythonShell.run('../main.py', null)
    .then(() => res.send('AI session done'))
    .catch(err => {
      console.error('Python error:', err);
      res.status(500).send('Error running AI');
    });
});

app.listen(port, () => {
  console.log(`🧠 Humane-AI backend running at http://localhost:${port}`);
});
