class LandingPage {
    constructor() {
        this.init();
    }
    
    init() {
        this.setupNavigation();
        this.setupFormHandling();
        this.setupSectionAnimations();
        this.startBackgroundAnimations();
    }
    
    setupNavigation() {
        const navItems = document.querySelectorAll('.nav-item');
        const sections = document.querySelectorAll('section[id]');
        
        // Smooth scroll navigation
        navItems.forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                const targetId = item.getAttribute('data-section');
                const targetSection = document.getElementById(targetId);
                
                if (targetSection) {
                    targetSection.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                    
                    // Update active state
                    navItems.forEach(nav => nav.classList.remove('active'));
                    item.classList.add('active');
                }
            });
        });
        
        // Update navigation on scroll
        const observerOptions = {
            threshold: 0.5,
            rootMargin: '-100px 0px -100px 0px'
        };
        
        const sectionObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const targetNav = document.querySelector(`[data-section="${entry.target.id}"]`);
                    if (targetNav) {
                        navItems.forEach(nav => nav.classList.remove('active'));
                        targetNav.classList.add('active');
                    }
                }
            });
        }, observerOptions);
        
        sections.forEach(section => {
            sectionObserver.observe(section);
        });
    }
    
    setupFormHandling() {
        const nameForm = document.getElementById('nameForm');
        const nameInput = document.getElementById('userName');
        
        if (nameForm && nameInput) {
            nameForm.addEventListener('submit', (e) => {
                e.preventDefault();
                const userName = nameInput.value.trim();
                
                if (userName) {
                    this.handleUserLogin(userName);
                }
            });
            
            // Add real-time validation
            nameInput.addEventListener('input', () => {
                const value = nameInput.value.trim();
                const submitBtn = nameForm.querySelector('.start-btn');
                
                if (value.length >= 2) {
                    submitBtn.style.opacity = '1';
                    submitBtn.disabled = false;
                } else {
                    submitBtn.style.opacity = '0.6';
                    submitBtn.disabled = true;
                }
            });
        }
    }
    
    async handleUserLogin(userName) {
        const submitBtn = document.querySelector('.start-btn');
        const originalText = submitBtn.innerHTML;
        
        // Show loading state
        submitBtn.innerHTML = `
            <div class="loading-spinner"></div>
            <span>Preparing your experience...</span>
        `;
        submitBtn.disabled = true;
        
        try {
            // Store user name
            localStorage.setItem('humane_ai_user', userName);
            
            // Add loading styles
            const style = document.createElement('style');
            style.textContent = `
                .loading-spinner {
                    width: 18px;
                    height: 18px;
                    border: 2px solid rgba(255,255,255,0.3);
                    border-top: 2px solid white;
                    border-radius: 50%;
                    animation: spin 1s linear infinite;
                }
                @keyframes spin {
                    0% { transform: rotate(0deg); }
                    100% { transform: rotate(360deg); }
                }
            `;
            document.head.appendChild(style);
            
            // Simulate loading delay
            await new Promise(resolve => setTimeout(resolve, 2000));
            
            // Redirect to chat interface
            window.location.href = 'app.html';
            
        } catch (error) {
            console.error('Login error:', error);
            submitBtn.innerHTML = originalText;
            submitBtn.disabled = false;
            
            // Show error message
            this.showNotification('Something went wrong. Please try again.', 'error');
        }
    }
    
    setupSectionAnimations() {
        // Animate statistics counter
        const stats = document.querySelectorAll('.stat-number');
        const statsObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    this.animateCounter(entry.target);
                }
            });
        }, { threshold: 0.5 });
        
        stats.forEach(stat => {
            if (!stat.dataset.animated) {
                statsObserver.observe(stat);
            }
        });
        
        // Feature cards hover effects
        const featureCards = document.querySelectorAll('.feature-card');
        featureCards.forEach((card, index) => {
            card.style.animationDelay = `${index * 0.2}s`;
            
            card.addEventListener('mouseenter', () => {
                if (window.animationController) {
                    window.animationController.createParticles(card, 10);
                }
            });
        });
    }
    
    animateCounter(element) {
        if (element.dataset.animated) return;
        
        const finalText = element.textContent;
        const hasNumber = /[\d.]+/.test(finalText);
        
        if (hasNumber) {
            const number = parseFloat(finalText.match(/[\d.]+/)[0]);
            const suffix = finalText.replace(/[\d.]+/, '');
            let current = 0;
            const increment = number / 50;
            
            const timer = setInterval(() => {
                current += increment;
                if (current >= number) {
                    current = number;
                    clearInterval(timer);
                    element.dataset.animated = 'true';
                }
                
                if (number < 1) {
                    element.textContent = current.toFixed(1) + suffix;
                } else {
                    element.textContent = Math.floor(current) + suffix;
                }
            }, 40);
        }
    }
    
    startBackgroundAnimations() {
        // Add floating particles to background
        const heroSection = document.querySelector('.hero-section');
        if (heroSection && window.animationController) {
            window.animationController.createParticles(heroSection, 30);
        }
        
        // Animate preview images
        const previewCards = document.querySelectorAll('.preview-card');
        previewCards.forEach(card => {
            const image = card.querySelector('.preview-image');
            if (image) {
                // Add subtle floating animation
                image.style.animation = 'float 6s ease-in-out infinite';
            }
        });
    }
    
    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 1rem 1.5rem;
            border-radius: var(--radius);
            background: var(--bg-secondary);
            border: 1px solid var(--border-color);
            color: var(--text-primary);
            z-index: 10000;
            transform: translateX(100%);
            transition: transform 0.3s var(--ease);
        `;
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        // Animate in
        requestAnimationFrame(() => {
            notification.style.transform = 'translateX(0)';
        });
        
        // Remove after 3 seconds
        setTimeout(() => {
            notification.style.transform = 'translateX(100%)';
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 300);
        }, 3000);
    }
}

// Initialize landing page
document.addEventListener('DOMContentLoaded', () => {
    new LandingPage();
});
        