// Global animation utilities
class AnimationController {
    constructor() {
        this.observers = [];
        this.init();
    }
    
    init() {
        this.setupScrollAnimations();
        this.setupHoverEffects();
        this.setupTypingAnimations();
    }
    
    setupScrollAnimations() {
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('animate-in');
                }
            });
        }, observerOptions);
        
        // Observe all animation targets
        document.querySelectorAll('.fade-in-up, .fade-in-left, .fade-in-right').forEach(el => {
            observer.observe(el);
        });
        
        this.observers.push(observer);
    }
    
    setupHoverEffects() {
        document.querySelectorAll('.glass-card').forEach(card => {
            card.addEventListener('mouseenter', () => {
                card.style.transform = 'translateY(-5px)';
            });
            
            card.addEventListener('mouseleave', () => {
                card.style.transform = 'translateY(0)';
            });
        });
    }
    
    setupTypingAnimations() {
        const typeElements = document.querySelectorAll('.typing-animation');
        
        typeElements.forEach(element => {
            const lines = element.querySelectorAll('.title-line');
            lines.forEach((line, index) => {
                line.style.animationDelay = `${index * 0.3}s`;
            });
        });
    }
    
    // Utility method to animate elements programmatically
    animateElement(element, animation, duration = 800) {
        return new Promise(resolve => {
            element.style.animation = `${animation} ${duration}ms var(--ease) both`;
            setTimeout(resolve, duration);
        });
    }
    
    // Method to create particle effects
    createParticles(container, count = 50) {
        for (let i = 0; i < count; i++) {
            const particle = document.createElement('div');
            particle.className = 'particle';
            particle.style.cssText = `
                position: absolute;
                width: 2px;
                height: 2px;
                background: hsl(${Math.random() * 360}, 70%, 60%);
                border-radius: 50%;
                pointer-events: none;
                animation: float ${3 + Math.random() * 4}s ease-in-out infinite;
                left: ${Math.random() * 100}%;
                top: ${Math.random() * 100}%;
                opacity: ${0.3 + Math.random() * 0.7};
            `;
            container.appendChild(particle);
        }
    }
    
    cleanup() {
        this.observers.forEach(observer => observer.disconnect());
    }
}

// Color theme utilities
class ThemeManager {
    constructor() {
        this.currentTheme = 'dark';
        this.hue1 = 255;
        this.hue2 = 222;
        this.init();
    }
    
    init() {
        this.updateCSSVariables();
        this.setupRandomColors();
    }
    
    updateCSSVariables() {
        document.documentElement.style.setProperty('--hue1', this.hue1);
        document.documentElement.style.setProperty('--hue2', this.hue2);
    }
    
    setupRandomColors() {
        // Generate complementary colors
        const baseHue = 120 + Math.floor(Math.random() * 240);
        this.hue1 = baseHue;
        this.hue2 = (baseHue + 60 + Math.floor(Math.random() * 60)) % 360;
        this.updateCSSVariables();
    }
    
    toggleTheme() {
        this.currentTheme = this.currentTheme === 'dark' ? 'light' : 'dark';
        document.body.className = this.currentTheme + '-theme';
        return this.currentTheme;
    }
    
    setCustomColors(hue1, hue2) {
        this.hue1 = hue1;
        this.hue2 = hue2;
        this.updateCSSVariables();
    }
}

// Initialize on DOM load
let animationController;
let themeManager;

document.addEventListener('DOMContentLoaded', () => {
    animationController = new AnimationController();
    themeManager = new ThemeManager();
});

// Export for use in other scripts
window.AnimationController = AnimationController;
window.ThemeManager = ThemeManager;
