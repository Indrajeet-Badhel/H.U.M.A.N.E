// web/scripts/orb.js
const orb = document.getElementById('orb');
const status = document.getElementById('status');

setTimeout(() => {
  orb.classList.add('listening');
  status.textContent = '🎤 Listening... Please look at the camera';
}, 1000);

// Trigger Python backend via local Node.js
fetch('http://localhost:5050/run')
  .then(res => res.text())
  .then(data => {
    status.textContent = '✅ Session complete. You may close this window.';
    orb.classList.remove('listening');
  })
  .catch(err => {
    status.textContent = '❌ Error starting AI.';
    console.error(err);
  });
// Update orb.js with proper error handling and fallback
fetch('http://localhost:5050/run')
  .then(res => {
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return res.text();
  })
  .then(data => {
    status.textContent = '✅ Session complete. You may close this window.';
    orb.classList.remove('listening');
  })
  .catch(err => {
    status.textContent = '⚠️ Backend unavailable. Running in demo mode.';
    // Add demo mode functionality here
    console.error('Backend connection failed:', err);
  });
