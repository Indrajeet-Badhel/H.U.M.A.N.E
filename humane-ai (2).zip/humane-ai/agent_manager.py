import re
import random

from prompt_converter.guardian_check import is_content_appropriate
from memory.memory_manager import MemoryManager

from agents.conversational_agent import ConversationalAgent
from agents.webscraping_agent import WebScrapingAgent
from agents.personalised_agent import PersonalisedAgent
from agents.summarization_agent import SummarizationAgent
from agents.translation_agent import TranslationAgent
from agents.research_agent import ResearchAgent
from agents.code_generation_agent import CodeGenerationAgent
from agents.general_agent import GeneralAgent
from agents.personality_core import apply_personality

# Ontology mapping
ONTOLOGY_MAP = {
    "//dbpedia.org/ontology/city": "city",
    "//dbpedia.org/ontology/university": "university",
    "//dbpedia.org/ontology/settlement": "region",
    "//dbpedia.org/ontology/person": "person",
    "//dbpedia.org/ontology/youtuber": "youtuber",
    "//dbpedia.org/ontology/disease": "disease",
    "//dbpedia.org/ontology/militaryunit": "militaryunit"
}

def map_ontology_keys(personal_info):
    mapped = {}
    for k, v in personal_info.items():
        mapped[ONTOLOGY_MAP.get(k, k)] = v
    return mapped

def build_prompt(agent_type, personal_info, user_input, required_fields=None):
    required_fields = required_fields or ["name", "age", "institution"]
    missing = [field for field in required_fields if not personal_info.get(field)]

    def normalize_value(val):
        if isinstance(val, list):
            return ', '.join(str(v) for v in val if v)
        return str(val)

    info_str = ', '.join(f"{k}: {normalize_value(v)}" for k, v in personal_info.items() if v)
    if missing:
        missing_str = ', '.join(missing)
        info_str += f". [Missing fields: {missing_str}]"

    templates = {
        "webscraping": "Webscraping prompt. User info: {info}. Task: {input}",
        "personalised": "Personalised agent prompt. User info: {info}. Input: {input}",
        "summarization": "Summarize for user ({info}): {input}",
        "translation": "Translate for user ({info}): {input}",
        "research": "Research task for user ({info}): {input}",
        "code_generation": "Code generation task. User: {info}. Request: {input}"
    }

    prompt = templates.get(agent_type, "Prompt: {input}").format(info=info_str, input=user_input)
    return prompt

def normalize_personal_info(personal_info):
    cleaned = {}
    for k, v in personal_info.items():
        values = v if isinstance(v, list) else [v]
        split_vals = []
        for item in values:
            if isinstance(item, str) and (' and ' in item or ',' in item):
                split_vals.extend([s.strip() for s in re.split(r' and |,', item)])
            else:
                split_vals.append(item)
        split_vals = [s for s in split_vals if s and s.lower() != "class"]
        if split_vals:
            cleaned[k] = split_vals if len(split_vals) > 1 else split_vals[0]
    return cleaned

# --------- Personality Selection Logic ---------
SENTIMENT_TO_PERSONALITIES = {
    "Positive": ["humorous", "funny", "happy", "cheerful", "motivational", "flirty"],
    "Neutral": ["humorous", "funny", "cheerful", "motivational"],
    "Negative": ["funny", "angry", "sad", "motivational", "humorous"]
}

def pick_personality(sentiment):
    options = SENTIMENT_TO_PERSONALITIES.get(sentiment, ["humorous"])
    return random.choice(options)

# ---------- Agent Manager ----------
class AgentManager:
    def __init__(self):
        self.memory_manager = MemoryManager()
        self.general_agent = GeneralAgent()
        self.conversational_agent = ConversationalAgent()  # Add this line
        
        self.agents = {
            "webscraping": WebScrapingAgent(),
            "personalised": PersonalisedAgent(),
            "summarization": SummarizationAgent(),
            "translation": TranslationAgent(),
            "research": ResearchAgent(),
            "code_generation": CodeGenerationAgent(),
            "conversational": self.conversational_agent  # Add this line
        }

    def classify_user_intent(self, user_input, image_caption=""):
        """Classify if this is a personal/conversational query or informational"""
        personal_indicators = [
            "do you think", "how do i look", "am i", "what should i wear",
            "your opinion", "about me", "feel about", "like me", "good looking"
        ]
        
        emotional_indicators = [
            "sad", "happy", "worried", "excited", "nervous", "confident",
            "feeling", "emotion", "mood"
        ]
        
        user_lower = user_input.lower()
        
        # Check for personal questions
        if any(indicator in user_lower for indicator in personal_indicators):
            return "conversational"
        
        # Check for emotional content
        if any(indicator in user_lower for indicator in emotional_indicators):
            return "conversational"
        
        # Check for food/appearance context with image
        if image_caption and ("food" in image_caption.lower() or "person" in image_caption.lower()):
            if any(word in user_lower for word in ["look", "think", "opinion", "good", "like"]):
                return "conversational"
        
        # Default to informational for complex queries
        return "informational"

    def generate_and_route_prompts(self, img_caption, user_voice, sentiment, sentiment_scores, extracted_info):
        personal_info = self.memory_manager.get_personal_info().copy()
        personal_info.update(extracted_info)
        personal_info = normalize_personal_info(personal_info)
        personal_info = map_ontology_keys(personal_info)
        
        # Classify the user's intent
        intent = self.classify_user_intent(user_voice, img_caption)
        
        # Choose personality style based on sentiment
        style = pick_personality(sentiment)
        
        responses = {}
        
        if intent == "conversational":
            # For personal/conversational queries, prioritize the conversational agent
            conv_response = self.conversational_agent.handle_prompt(
                user_voice, 
                style=style,
                user_input=user_voice,
                image_caption=img_caption,
                user_info=personal_info
            )
            
            responses["conversational"] = conv_response
            
            # Also get a general response as backup
            general_response = self.general_agent.handle_prompt(
                f"Respond in a {style} way to: {user_voice}"
            )
            responses["general"] = general_response
            
        else:
            # For informational queries, use all agents as before
            for agent_type, agent in self.agents.items():
                if agent_type == "conversational":
                    continue  # Skip for informational queries
                    
                context = f"Image: {img_caption}\nVoice: {user_voice}\nSentiment: {sentiment}"
                prompt = build_prompt(agent_type, personal_info, context)
                styled_prompt = apply_personality(prompt, style=style)
                
                if not is_content_appropriate(styled_prompt):
                    responses[agent_type] = "Prompt flagged as inappropriate."
                    continue
                
                try:
                    responses[agent_type] = agent.handle_prompt(styled_prompt)
                except Exception as e:
                    responses[agent_type] = f"{agent_type} error: {str(e)}"
        
        return responses